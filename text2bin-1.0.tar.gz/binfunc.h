void convertToBinary(std::string word, char letter);
