# text2bin

[![Build Status](https://dev.azure.com/chanakan5591/text2bin/_apis/build/status/Chanakan5591.text2bin?branchName=master)](https://dev.azure.com/chanakan5591/text2bin/_build/latest?definitionId=4&branchName=master)
